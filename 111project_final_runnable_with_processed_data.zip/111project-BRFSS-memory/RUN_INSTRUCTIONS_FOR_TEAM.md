# Final Runnable BRFSS Project Package

This package includes the files needed to run the app and retrain/evaluate the BRFSS model.

## Included
- `app.py` and `streamlit_app.py` for the backend/frontend app
- `src/` and `backend/` project code
- `requirements.txt`
- `brfss_2024_eda_processed.csv` processed data for retraining
- `train_brfss_option_b.py` final training/evaluation script
- `artifacts/model.pkl` trained model artifact
- `artifacts/preprocessor.pkl` and `artifact/preprocessor.pkl` preprocessor artifact
- evaluation report/graphs in `artifacts/` if generated

## Not included
- `.env`
- `.venv`
- `saved_profiles.json`
- `__pycache__`
- `.DS_Store`

## Setup
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install matplotlib openpyxl tabulate
```

Create your own `.env` file:
```text
GROQ_API_KEY=your_key_here
```

## Run the app
Terminal 1:
```bash
uvicorn app:app --reload
```

Terminal 2:
```bash
source .venv/bin/activate
streamlit run streamlit_app.py
```

Open:
```text
http://localhost:8501
```

## Retrain/evaluate model
```bash
python3 train_brfss_option_b.py
```

This produces/updates:
- `artifacts/model.pkl`
- `artifact/preprocessor.pkl`
- `artifacts/preprocessor.pkl`
- `artifacts/brfss_final_training_report.txt`
- PNG evaluation graphs
