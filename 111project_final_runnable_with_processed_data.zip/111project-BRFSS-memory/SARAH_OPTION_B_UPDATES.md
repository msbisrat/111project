# Sarah Option B Updates

This zip is based on the latest `BRFSS-memory` version your teammate shared.

Files changed or added:

1. `train_brfss_option_b.py`
   - Replaced the simpler training script with an enhanced training/evaluation pipeline.
   - Added a true baseline stage that uses mostly default model settings and does not use `class_weight="balanced"`.
   - Added an after-tuning stage that uses imbalance handling and larger Random Forest sizes.
   - Random Forest now tests `n_estimators=100` and `n_estimators=200` instead of only 50.
   - Added progress printing during training, including run number, model name, parameters, training time, validation metrics, and total elapsed time.
   - Model selection focuses on heart disease class F1-score and recall using `0.60 * F1 + 0.40 * recall`.
   - ROC AUC is still reported, but it is not the main model selection metric.
   - Saves readable tables as HTML and TXT, plus CSV and optional Excel if `openpyxl` is installed.
   - Generates evaluation graphs for F1, recall, before/after tuning comparison, and final confusion matrix.
   - Saves `preprocessor.pkl` to both `artifact/` and `artifacts/` so the app can load it regardless of which path is used.

2. `src/mlproject/predict_pipelines.py`
   - Updated defaults from old UCI clinical fields to BRFSS features.
   - Added fallback loading for preprocessor from either `artifacts/preprocessor.pkl` or `artifact/preprocessor.pkl`.
   - This helps prediction work when users leave optional fields blank.

3. `streamlit_app.py`
   - Improved the save/load profile behavior.
   - Loading a profile now updates Streamlit widget values directly through `st.session_state`.
   - Converts saved numeric BRFSS codes back into selectbox labels.
   - Converts saved text input values into strings to avoid Streamlit `TypeError`.

4. `app.py`
   - Updated health-check text so it shows both possible preprocessor paths.

5. `requirements.txt`
   - Added `matplotlib` for evaluation graphs.
   - Added `openpyxl` for optional Excel outputs.
   - Fixed `mflow-skinny` typo to `mlflow-skinny`.

6. `brfss_2024_eda_processed.csv`
   - Included in the project root so `python3 train_brfss_option_b.py` can run directly.

Main command:

```bash
python3 train_brfss_option_b.py
```

Expected useful outputs:

- `artifacts/model.pkl`
- `artifact/preprocessor.pkl`
- `artifacts/preprocessor.pkl`
- `artifacts/brfss_tuning_results.html`
- `artifacts/brfss_summary_table.html`
- `artifacts/brfss_test_metrics.html`
- `artifacts/brfss_tuning_results_readable.txt`
- `artifacts/brfss_best_model_test_report.txt`
- `artifacts/brfss_validation_f1_comparison.png`
- `artifacts/brfss_validation_recall_comparison.png`
- `artifacts/brfss_before_after_best_f1_recall.png`
- `artifacts/brfss_test_confusion_matrix.png`
