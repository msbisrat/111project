# src/mlproject/predict_pipelines.py

import pickle
from pathlib import Path
import pandas as pd


class PredictPipeline:
    def __init__(self):
        model_path = Path("artifacts/model.pkl")
        preprocessor_paths = [
            Path("artifacts/preprocessor.pkl"),
            Path("artifact/preprocessor.pkl"),
        ]

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)

        preprocessor_path = next((p for p in preprocessor_paths if p.exists()), None)
        if preprocessor_path is None:
            raise FileNotFoundError(
                "Could not find preprocessor.pkl in artifacts/ or artifact/. "
                "Run python3 train_brfss_option_b.py first."
            )

        with open(preprocessor_path, "rb") as f:
            self.preprocessor = pickle.load(f)

    def _to_df(self, data: dict) -> pd.DataFrame:
        """
        Convert input dict to a one-row DataFrame.
        Missing BRFSS inputs are filled with neutral/common defaults so the
        preprocessor can still run when users leave fields blank.
        """
        defaults = {
            "Sex": 2.0,
            "AgeCategory": 7.0,
            "Education": 5.0,
            "Income": 7.0,
            "EmploymentStatus": 1.0,
            "MaritalStatus": 5.0,
            "HomeOwnership": 2.0,
            "GeneralHealth": 3.0,
            "GoodOrBetterHealth": 1.0,
            "LastCheckup": 1.0,
            "Height": 506.0,
            "Weight": 170.0,
            "Smoked100Cigarettes": "No",
            "SmokerStatus": 4.0,
            "ECigaretteUsage": 4.0,
            "SmokelessTobaccoUse": 3.0,
            "AlcoholDays": 888.0,
            "PhysicalActivities": 1.0,
            "HadDiabetes": "No",
            "HadKidneyDisease": "No",
            "HadStroke": "No",
            "HadCOPD": "No",
            "HadDepressiveDisorder": "No",
            "HadArthritis": "No",
        }

        filled = defaults.copy()
        for key, value in data.items():
            if value is not None and value != "":
                filled[key] = value

        return pd.DataFrame([filled])

    def predict(self, data: dict) -> int:
        df = self._to_df(data)
        transformed = self.preprocessor.transform(df)
        return int(self.model.predict(transformed)[0])

    def predict_proba(self, data: dict) -> float:
        df = self._to_df(data)
        transformed = self.preprocessor.transform(df)

        if hasattr(self.model, "predict_proba"):
            proba = self.model.predict_proba(transformed)[0]
            return float(proba[1])

        prediction = int(self.model.predict(transformed)[0])
        return 0.75 if prediction == 1 else 0.25
